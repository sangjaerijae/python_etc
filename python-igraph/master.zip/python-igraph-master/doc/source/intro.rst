.. include:: include/global.rst

.. Introduction

============
Introduction
============

What is |igraph|?
=================

Things you should know before starting out
==========================================

Reporting bugs and providing feedback
=====================================

