Graph generation
================

.. note:: TODO. This is a placeholder section; it is not written yet.

